import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

main() {
  runApp(const ShowInfo());
}

class ShowInfo extends StatefulWidget {
  const ShowInfo({super.key});

  @override
  State<ShowInfo> createState() => _ShowInfoState();
}

class _ShowInfoState extends State<ShowInfo> {
  List list = [];

  final TextEditingController _nameCon = TextEditingController();
  final TextEditingController _emailCon = TextEditingController();
  final TextEditingController _phoneCon = TextEditingController();
  final TextEditingController _addressCon = TextEditingController();

  Future<String> listData() async {
    var response = await http.get(Uri.http('10.110.1.91:80', 'emp'),
        headers: {"Accept": "application/json"});
    print('Respnse status: ${response.statusCode}');
    print('Respnse body: ${response.body}');
    setState(() {
      list = jsonDecode(response.body);
    });
    return "Success";
  }

  @override
  void initState() {
    super.initState();
    listData();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("DB TEST"),
      ),
      body: Center(
        child: ListView.builder(
          itemCount: list.length,
          itemBuilder: (BuildContext context, int index) {
            return Card(
              child: ListTile(
                title: Row(
                  children: [
                    Expanded(child: Text(list[index]["name"])),
                    Expanded(child: Text(list[index]["email"])),
                  ],
                ),
                leading: Text(list[index]["id"].toString()),
                trailing: Wrap(
                  spacing: 5,
                  children: [
                    IconButton(
                      onPressed: () {
                        Map data = {
                          'id': list[index]['id'],
                          'name': list[index]['name'],
                          'email': list[index]['email'],
                          'phone': list[index]['phone'],
                          'address': list[index]['address'],
                        };
                        _showEdit(data);
                      },
                      icon: Icon(Icons.edit, color: Colors.green),
                    ),
                    IconButton(
                      onPressed: () => _showDel(list[index]['id']),
                      icon: Icon(Icons.delete_outline, color: Colors.red),
                    ),
                  ],
                ),
              ),
            );
          },
        ),
      ),
      floatingActionButton: FloatingActionButton(
          child: const Icon(Icons.add),
          onPressed: () {
            _addNewDialog();
          }),
    );
  }

  Future<void> _addNewDialog() async {
    return showDialog<void>(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('AlertDialog Title'),
          content: SingleChildScrollView(
            child: ListBody(
              children: <Widget>[
                TextField(
                  controller: _nameCon,
                  decoration: const InputDecoration(
                      hintText: "Enter emp Name", labelText: 'Name:'),
                ),
                TextField(
                  controller: _emailCon,
                  decoration: const InputDecoration(
                      hintText: "Enter emp Email", labelText: 'Email:'),
                ),
                TextField(
                  controller: _phoneCon,
                  decoration: const InputDecoration(
                      hintText: "Enter emp Phone", labelText: 'Phone:'),
                ),
                TextField(
                  controller: _addressCon,
                  decoration: const InputDecoration(
                      hintText: "Enter emp Address", labelText: 'Address:'),
                ),
                const Text("กรอกข้อมูลให้เรียบร้อยแล้วกด ยืนยัน")
              ],
            ),
          ),
          actions: <Widget>[
            TextButton(
                onPressed: () {
                  add_data();
                  Navigator.of(context).pop();
                },
                child: const Text("ยืนยัน"))
          ],
        );
      },
    );
  }

  Future<void> _showDel(int id) async {
    return showDialog<void>(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('ลบข้อมูล ${id}'),
          content: SingleChildScrollView(
            child: ListBody(
              children: const [
                Text('ยืนยันการลบข้อมูล กด ยืนยัน'),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () {
                del_data(id);
                Navigator.of(context).pop();
              },
              child: const Text('ยืนยัน'),
            ),
          ],
        );
      },
    );
  }

  void add_data() async {
    Map data = {
      'name': _nameCon.text,
      'email': _emailCon.text,
      'phone': _phoneCon.text,
      'address': _addressCon.text,
    };
    var body = jsonEncode(data);
    var response = await http.post(
      Uri.http('10.110.1.91:80', 'create'),
      headers: {
        "Content-Type": "application/json",
        "Accept": "application/json"
      },
      body: body,
    );
    print('Response status: ${response.statusCode}');
    print('Response body: ${response.body}');
    listData();
  }

  void del_data(int id) async {
    var response = await http.delete(
      Uri.http('10.110.1.91:80', 'delete/$id'),
      headers: <String, String>{
        'Content-Type': 'application/json; charset=UTF-8',
        "Accept": "application/json"
      },
    );
    print('Response status: ${response.statusCode}');
    print('Response body: ${response.body}');
    listData();
  }

  Future<void> _showEdit(Map data) async {
    _nameCon.text = data['name'];
    _emailCon.text = data['email'];
    _phoneCon.text = data['phone'];
    _addressCon.text = data['address'];
    return showDialog(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('ทดสอบการ Edit'),
          content: SingleChildScrollView(
            child: ListBody(
              children: <Widget>[
                TextField(
                  controller: _nameCon,
                  decoration: const InputDecoration(
                      hintText: "Enter emp name", labelText: 'Name:'),
                ),
                TextField(
                  controller: _nameCon,
                  decoration: const InputDecoration(
                      hintText: "Enter emp email", labelText: 'Email:'),
                ),
                TextField(
                  controller: _nameCon,
                  decoration: const InputDecoration(
                      hintText: "Enter emp phone", labelText: 'Phone:'),
                ),
                TextField(
                  controller: _nameCon,
                  decoration: const InputDecoration(
                      hintText: "Enter emp Address", labelText: 'Address:'),
                ),
                const Text('ปรับปรุงข้อมูลให้เรียบร้อยแล้ว กด ยืนยัน'),
              ],
            ),
          ),
          actions: <Widget>[
            TextButton(
              onPressed: () {
                edit_data(data['id']);
                Navigator.of(context).pop();
              },
              child: const Text('ยืนยัน'),
            ),
          ],
        );
      },
    );
  }

  void edit_data(id) async {
    Map data = {
      'name': _nameCon.text,
      'email': _emailCon.text,
      'phone': _phoneCon.text,
      'address': _addressCon.text,
    };
    var body = jsonEncode(data);
    var response = await http.put(
      Uri.http('10.110.1.91:80', 'update/$id'),
      headers: <String, String>{
        'Content-Type': 'application/json; charset=UTF-8',
      },
      body: body,
    );
    print('Response status: ${response.statusCode}');
    print('Response body: ${response.body}');
    listData();
  }
}
